/**
 * @author YXH_XianYu
 * Created On 2022-04-19
 */
public class Spider extends Animal {

    public Spider() {
        super(8);
    }

    @Override
    public void eat() {
        System.out.println("The spider is eating.");
    }
}
