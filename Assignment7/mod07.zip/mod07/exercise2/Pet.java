/**
 * @author YXH_XianYu
 * Created On 2022-04-19
 */
public interface Pet {
    public String getName();

    public void setName(String name);

    public void play();
}
